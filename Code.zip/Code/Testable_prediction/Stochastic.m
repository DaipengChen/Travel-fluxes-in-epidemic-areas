function [xx,xy,ST]=Stochastic(T,Par,eps)

t1=1:80;t2=1:100;
for i=1:29
    [I(:,i),R(i,:)]=Solu(i,Par,t1,t2);
end

ST=1+round(Par(:,3))+T-5;
F0=diag(I(ST,:));
R0=eps*diag(R(:,ST-T+1))+(1-eps)*diag(R(:,ST)); 
for i=1:29
    for j=1:29
        if i==j
            B(i,j)=0;
        else
            B(i,j)=0.0003*rand; % movement matrix
        end
    end
end
B=B-diag(sum(B));
C=(B+diag(R0));
tspan=0:0.1:50;
[~,y]=ode45(@(t,y) C*y,tspan,F0);
Y=zeros(45,29);
for i=1:29
    Y(1:ST(i),i)=I(1:ST(i),i);
    Y(ST(i):end,i)=y(1:10:460-10*ST(i),i);
    tt=1:44;yy=Y(1:44,i);
    xx=linspace(tt(1),tt(end));
    xy(i,:)=spline(tt,yy,xx);
end

end