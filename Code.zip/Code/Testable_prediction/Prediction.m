function [x,row,Id,Y]=Prediction(N,T,Par,S,eps,sigma)
t1=1:80;t2=1:100;
for i=1:29
    [I(:,i),R(i,:)]=Solu(i,Par,t1,t2);
end
[x,~]=Selecting_regions(T,eps,Par,1:100,1:120);
[row,~]=find(x>0);
par=Par(row,1:5);
[B,Id]=Travel_flow(N,T,eps,Par,S,1:100,1:120,sigma);
I=I(:,row(Id));
R=R(row(Id),:);
parl=par(Id,:);
ST=1+round(parl(:,3))+T-5;
F0=diag(I(ST,:));
R0=eps*diag(R(:,ST-T+1))+(1-eps)*diag(R(:,ST));
B=B-diag(sum(B));
C=(B+diag(R0));
tspan=0:0.1:50;
[~,y]=ode45(@(t,y) C*y,tspan,F0);
Y=zeros(45,length(row));
for i=1:length(row)
    Y(1:ST(i),i)=I(1:ST(i),i);
    Y(ST(i):end,i)=y(1:10:460-10*ST(i),i);
end
end