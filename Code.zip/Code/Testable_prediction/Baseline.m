% This a part of the code is used for testable prediction. 

clc
clear
close all

%% Input
load('C:\Users\Daipeng1993\Desktop\Code\Data\New_cases.mat'); %COVID-19 cases
load('C:\Users\Daipeng1993\Desktop\Code\Data\Growth_rate.mat'); %Estimated growth rate

%% Parameters
T=18; %time
C=7;  %city

%% Calculation
[~,~,ST]=Stochastic(T,par,0.1);
SY=ST(C);

%% Output figure
scatter(1:SY,New(C,1:SY),20,'b','filled')
hold on
for i=1:5
eps=0.1*i+0.05;
[xx,xy,~]=Stochastic(T,par,eps);
plot(xx,xy(C,:),'LineWidth',1.5,'Color',[eps+0.3,0.2,0])
hold on
end
[xx,xy,~]=Stochastic(T,par,0.15);
plot(xx,xy(C,:),'LineWidth',1.5,'Color',[0.45,0.2,0])
legend('Data','\epsilon=0.15','\epsilon=0.25','\epsilon=0.35',...
    '\epsilon=0.45','\epsilon=0.55','location','northwest');
xlabel('Date of the outbreak period')
ylabel('New reported cases')
set(gca,'XTick',0:5:45);
C={'Jan 22' 'Jan 27' 'Feb 1' 'Feb 6' 'Feb 11' 'Feb 16' 'Feb 21' 'Feb 26',...
    'Mar 2','Mar 7','Mar 12','Mar 17','Mar 22'};
set(gca,'XTickLabel',C);
xtickangle(30)
axis([0 45 0 90])
title('Baseline movements')
