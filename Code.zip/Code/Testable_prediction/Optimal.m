% This a part of the code is used for testable prediction. 

clc
clear
close all

%% Input
load('C:\Users\Daipeng1993\Desktop\Code\Data\New_cases.mat');
load('C:\Users\Daipeng1993\Desktop\Code\Data\Growth_rate.mat');
load('C:\Users\Daipeng1993\Desktop\Code\Data\Diffusion_distance.mat');

%% Parameters
N=2;
T=18;
sigma=0;
C=7;

%% Output claculation&figure
ST=1+round(par(C,3))+T-5;
sz=20;
scatter(1:ST,New(C,1:ST),sz,'b','filled')
hold on
for i=1:4
eps=0.1*i+0.05;
[~,row,Id,Y]=Prediction(N,T,par,S,eps,sigma);
label1=find(row==C);
label2=find(Id==label1);
tt=1:44;yy=Y(1:44,label2);
xx=linspace(tt(1),tt(end));
xy=spline(tt,yy,xx);
plot(xx,xy,'LineWidth',1.5,'Color',[eps+0.3,0.2,0])
hold on
end
[x,row,Id,Y]=Prediction(N,T,par,S,0.15,sigma);
label1=find(row==C);
label2=find(Id==label1);
tt=1:44;yy=Y(1:44,label2);
xx=linspace(tt(1),tt(end));
xy=spline(tt,yy,xx);
plot(xx,xy,'LineWidth',1.5,'Color',[0.45,0.2,0])

legend('Data','\epsilon=0.15','\epsilon=0.25','\epsilon=0.35','\epsilon=0.45');
xlabel('Date of the outbreak period')
ylabel('New reported cases')
set(gca,'XTick',0:5:45);
C1={'Jan 22' 'Jan 27' 'Feb 1' 'Feb 6' 'Feb 11' 'Feb 16' 'Feb 21' 'Feb 26',...
    'Mar 2','Mar 7','Mar 12','Mar 17','Mar 22'};
set(gca,'XTickLabel',C1);
xtickangle(30)
axis([0 45 0 90])
title('Optimal movements (\xi=0)')