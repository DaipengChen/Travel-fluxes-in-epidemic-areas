% This code is used to calculate the diffusion distance among cities

clc
clear
close all

%% Input relative population flow
load('C:\Users\Daipeng1993\Desktop\Code\Data\Population_flow.mat'); %population flow

%% Parameters
l=25;
[row,column]=size(W);
A=W+eye(row,column);
B=zeros(row,column);
S=zeros(row,column);
D=zeros(1,column);

%% Calculation
 for i=1:row
     sum_i=sum(A(i,:));
     for j=1:column
         B(i,j)=A(i,j)/sum_i;
     end
 end
T=B^(l);
for i=1:row
    for j=1:row
        for k=1:column
            D(k)=(T(i,k)-T(j,k))^2*sum(A(:,k))/sum(sum(A));
        end
        S(i,j)=sqrt(sum(D));
    end
end

%% Output
pathname = 'C:\Users\Daipeng1993\Desktop\Code\Data\';
filename = 'Diffusion_distance.mat';
save([pathname,filename],'S');